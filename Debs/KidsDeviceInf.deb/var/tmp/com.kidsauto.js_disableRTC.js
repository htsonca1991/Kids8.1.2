'use strict'; 
if (webkit.messageHandlers.iThanhRTC) { install(); } 

function install() { 
	function sendMessage(msg) { 
		if (msg) { webkit.messageHandlers.iThanhRTC.postMessage(msg); } 
	} 
	
	function installIFrameMethodTrap(obj, method) { 
		let orig = obj[method]; 
		obj[method] = function () { 
			var last = arguments[arguments.length - 1]; 
			if (last && last.toLowerCase() === '') { 
				sendMessage({ obj: `${obj}`, method: method });
			} 
			else { 
				return orig.apply(this, arguments);
			} 
		}; 
		return orig; 
	} 

	let hooks = [
		{ 
			obj: window.RTCPeerConnection.prototype, methods: ['createDataChannel']
		} 
	]; 

	hooks.forEach(function (hook) { 
		hook.methods.forEach(function (method) { 
			hook.obj[method] = function () { 
				sendMessage({ obj: `${hook.obj}`, method: method }); 
			} 
		}); 
	}); 

	if (window.frameElement) { 
		installIFrameMethodTrap(RTCPeerConnection, 'createDataChannel'); 
	} 
}


